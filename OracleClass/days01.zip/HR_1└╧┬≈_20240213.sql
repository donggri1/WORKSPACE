-- HR
SELECT *
FROM tabs;