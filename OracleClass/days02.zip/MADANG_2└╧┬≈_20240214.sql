-- MADANG
SELECT *
FROM tabs;
SELECT *
FROM book;
DESC book;
DESC imported_book;
SELECT *
FROM customer;
SELECT *
FROM orders;

SELECT *
FROM imported_book;
21	Zen Golf	Pearson	12000
22	Soccer Skills	Human Kinetics	15000
SELECT name"�̸�", NVL(phone,'����ó����')"��ȭ��ȣ"
FROM Customer;
