package tennis;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

public class Tenis extends GameMethod {//메인 클래스. 만들어둔 함수를 여기서 사용함.

   public static void main(String[] args) throws IOException {
	   
      Scanner scanner = new Scanner(System.in);
      GameMethod g = new GameMethod();
      Player p = new Player();
      String gender;

      System.out.println("\t"+"=".repeat(25));
      System.out.println();
      System.out.println("\t\t  테니스");
      System.out.println();
      System.out.println("\t"+"=".repeat(25));
      System.out.println();

      System.out.println(" →계속하려면 엔터를 누르세요");
      
      System.in.read();
      System.in.skip(System.in.available());
     
/*
      char con ='e';
      do {
         con = (char)System.in.read();
         System.in.skip(System.in.available());
      } while (Character.toUpperCase(con)=='e');
*/
		System.out.println( " 게임 인원을 입력하세요 ");
		int in = 0;
		in= scanner.nextInt();
		ArrayList<PlayerInfo> pi = new ArrayList<PlayerInfo>();
		for (int i = 0; i < in; i++) {
			System.out.printf("플레이어[ %d ]의 이름을 입력하세요");
			String pn=scanner.next();
			System.out.printf("플레이어[ %d ]의 성별을 입력하세요");
			String pg = scanner.next();
			PlayerInfo playerInfo = new PlayerInfo(pn, pg);
			pi.add(playerInfo);
		}
		
	      Iterator<PlayerInfo> ir = pi.iterator();
	      for(PlayerInfo i : pi) { //for문을 통한 전체출력
	    	    System.out.println(i);
		
      int set = g.getSet(in,pi);
      boolean mode = g.getMode(in,pi);
      Random rnd = new Random();
      //ArrayList <String> team1totalscore = new ArrayList <String>();
      boolean a= true;


      String [][] playername = p.Inputplayer(mode,pi);
      p.getteam1player(playername);
      p.getteam2player(playername);

      while(a) {
         g.pointWinner(rnd.nextInt(2)+1, set);
      }}}}
   

