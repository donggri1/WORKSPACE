package tennis_team_1;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class Tenis extends GameMethod {

	public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(System.in);

		GameMethod g = new GameMethod();
		Player p = new Player();

		String gender;

		System.out.println("\t"+"=".repeat(25));
		System.out.println();
		System.out.println("\t\t  테니스");
		System.out.println();
		System.out.println("\t"+"=".repeat(25));
		System.out.println();

		System.out.println(" →계속하려면 엔터를 누르세요");

		System.in.read();
		System.in.skip(System.in.available());

		System.out.print("성별(남자,여자,혼합)을 입력하세요");
		gender = sc.next();


		int set = g.getSet(gender);
		boolean mode = g.getMode(gender);
		Random rnd = new Random();
		//ArrayList <String> team1totalscore = new ArrayList <String>();
		boolean a= true;


		String [][] playername = p.Inputplayer(mode);
		p.getteam1player(playername);
		p.getteam2player(playername);

		while(a) {
			g.pointWinner(rnd.nextInt(2)+1, set);
		}
	}
}
