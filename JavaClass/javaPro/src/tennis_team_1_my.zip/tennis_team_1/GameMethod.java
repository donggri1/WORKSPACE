package tennis_team_1;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import tennis_team_1.Player;

public class GameMethod extends FileManager{
	public static int [][] scoreArr = new int [2][50]; //2팀 5세트까지 점수 저장 **************
	static int plus = 0; //*********************

	// 2팀과 3개의 점수 체계(포인트, 게임, 세트)
	static int [][] scores = new int[2][4]; //*******************
	DispScoreBoard dp = new DispScoreBoard();
	public static ArrayList <String> team1totalscore= new ArrayList<String>();
	public static ArrayList <String> team2totalscore= new ArrayList<String>();

	public int getSet(String gender) {
		//세트
		Scanner scanner = new Scanner(System.in);
		int selectSet =0;


		do {

			if (gender.contains("남자")) {
				selectSet =5;
			}else if (gender.contains("여자")|| gender.contains("혼합")) {
				selectSet =3;
			}else {
				System.out.println("성별(남자,여자,혼합)을 입력하세요");
			}
			//if

		} while (!gender.contains("남자") &&  !gender.contains("여자") &&  !gender.contains("혼합"));
		//do~while
		String nSet = String.format("%d세트", selectSet);

		do {

			//3세트
			if(selectSet == 3) {
				nSet = String.format("%d세트", selectSet);
				System.out.println("> " + nSet + "를 선택하셨습니다.");
			} // if

			//5세트
			else if(selectSet == 5) {
				nSet = String.format("%d세트", selectSet);
				System.out.println("> " + nSet + "를 선택하셨습니다.");
			} // else if

		} while( selectSet != 3 && selectSet != 5 );
		//do~while
		return selectSet;
	}

	public boolean getMode(String gender) {
		// 단식이면 true, 복식이면 false
		if (gender.contains("혼합")) {
			return false; // "혼합"이면 복식으로 설정
		}

		Scanner scanner = new Scanner(System.in);
		String modeStr = "";

		do {
			System.out.print("단식, 복식 경기 선택하세요: ");
			modeStr = scanner.next();

			// 단식
			if (modeStr.equals("단식")) {
				System.out.println("> 단식을 선택하셨습니다.");
				return true;
			}
			// 복식
			else if (modeStr.equals("복식")) {
				System.out.println("> 복식을 선택하셨습니다.");
				return false;
			} else {
				System.out.println("단식 혹은 복식을 선택해주세요.");
			}
		} while (!modeStr.equals("단식") && !modeStr.equals("복식"));

		return false; // 기본적으로 복식으로 설정
	}

	public void pointWinner(int p, int set) {

		String [] points = {"0", "15", "30", "40","AD","WIN"};

		scores[p-1][0]++;
		if (scores[p-1][0]==4) {
			System.out.printf("-".repeat(10)+"team%d 선수 승리"+"-".repeat(10),p);
			System.out.println();

		}else {
			dp.dispPointScore(scores[0][0], scores[1][0]);

		}//if


		// 포인트가 3-3(40-40)인 경우 듀스 룰 적용
		if (scores[0][0] == 3 && scores[1][0] == 3) {
			playDeuce(set,p);
		}//if

		// 한 팀의 포인트가 3(40) 이상이 되면 게임 점수 획득
		if (scores[p-1][0] > 3) {
			scores[p-1][0]++;//   수정된부분입니다.
			team1totalscore.add(points[scores[0][0]]);   //팀 1 점수 저장
			team2totalscore.add(points[scores[1][0]]);   //팀 2 점수 저장
			//         System.out.print(team1totalscore.toString());
			plusGame(p, set);
			scores[0][0] = scores[1][0] = 0;
		}

	}

	public void plusGame(int p, int set) {
		System.out.println("-".repeat(45)); 
		scores[p-1][1]++;
		dp.dispGameScore(scores[0][1], scores[1][1]);
		++scoreArr[p-1][plus]; //******************

		// 한 팀이 다른 팀보다 2게임 이상 앞서고 6게임 이상 먼저 따면 세트 점수 획득
		if (scores[p-1][1] - scores[2-p][1] >= 2 && scores[p-1][1] >= 6) {
			plusSet(p, set);
			team1totalscore.add("setchange");		//세트별 구분자 :
			team2totalscore.add("setchange");		//세트별 구분자 :
			scores[0][1] = scores[1][1] = 0;
			plus++; //***************
		}

	}

	public void plusSet(int p, int set) {

		scores[p-1][2]++; //********************
		dp.dispSetScore(scores[0][2], scores[1][2]);

		// 한 팀의 세트 점수가 총 세트 수의 절반 이상이면 승리
		if (scores[p-1][2] >= (set/2+1)) { //*******************
			if (p == 1)	{
				System.out.println("> Team 1(" + Player.team1player + ")승리");
			} 
			else {
				System.out.println("> Team 2(" +Player.team2player +  ")승리");
			}
			//plus++;


			totalscoreprint(p);
			System.out.println("-".repeat(45));             // 선
			System.exit(0);		//시스템 종료 ********************
		} //if
	}

	public void playDeuce(int set, int p) {
		System.out.println("================= Deuce =================");
		Random rnd = new Random();
		
		// 한 팀이 다른 팀보다 2점 선취할 때까지 반복
		scores[p-1][3]++;
		while (true) {
			
			p = rnd.nextInt(2)+1;
			
			if (p==1) {
	            scores[p-1][3]++;		//듀스스코어 1증가
	            if (scores[0][3]!=3) {			//듀스 3연승

	               scores[1][3]=0;				// 듀스점수 초기화
	               System.out.printf("Team1 : %s \t Team2 : %s\n","AD",  "");
	            }else if (scores[0][3]==3) {
	               System.out.println("-".repeat(10)+"Team1 승리"+"-".repeat(10));
	               System.out.println();
	               System.out.println();
	               System.out.println();
	               team1totalscore.add("WIN");
	               team2totalscore.add("40");
	               
	               plusGame(p, set);
	               scores[0][0] = scores[1][0] = 0;
	               scores[0][3] = scores[1][3] = 0;
	               break;
	            }//if
	         }//if

	         if (p==2) {
	            scores[p-1][3]++;
	            if (scores[1][3]!=3) {
	               scores[0][3]=0;
	               System.out.printf("Team1 : %s \t Team2 : %s\n","",  "AD");
	            }else if (scores[1][3]==3) {
	               System.out.println("-".repeat(10)+"Team2 승리"+"-".repeat(10));
	               System.out.println();
	               System.out.println();
	               System.out.println();
	               team1totalscore.add("40");
	               team2totalscore.add("WIN");

	               plusGame(p, set);
	               scores[0][0] = scores[1][0] = 0;
	               scores[0][3] = scores[1][3] = 0;
	               break;
	            }//if
	         }//if
	      }//while
	} //playDeuce

	public static void totalscoreprint(int p) {
		int set=1;

		int team1gamewin=0;                     //1세트에서 획득한 team1의 점수
		int team2gamewin=0;
		String setreport="";                        //세트별 점수 문자열

		String team1line="team1: (1세트) ";   //team1의 score 정리할 문자열
		String team2line="team2: (1세트) ";   //team2의 score를 정리할 문자열

		for(int i =0; i <team1totalscore.size(); i ++) {
			if(team1totalscore.get(i).equals("setchange")) {   //배열안에 포함된 setchange를 구분자로 세트를 나눈다.
				if(team1gamewin>team2gamewin) 
					setreport += set+"세트 "+team1gamewin +":"+team2gamewin+ " team1 승리\n";
				else setreport += set+"세트 "+team1gamewin +":"+team2gamewin+ " team2 승리\n";
				set++;                                                         //세트 +1
				team1line += "\n\t\t("+set+"세트)";
				team2line += "\n\t\t("+set+"세트) ";                     
				team1gamewin=team2gamewin=0;               //세트별 점수 초기화
			}//if

			else{
				team1line += team1totalscore.get(i)+ "\t";         //team1line에 team1totalscore 더하기
				team2line += team2totalscore.get(i)+ "\t";         //team2line에 team2totalscore 더하기
				if(team1totalscore.get(i).equals("AD")) team1gamewin++;   //한 세트 안에서 획득한 게임++
				else team2gamewin++;
			}//else
		}//for
		if(team1gamewin>team2gamewin)
			setreport += set+"세트 "+team1gamewin +":"+team2gamewin+ " team1 승리\n";
		else setreport += set+"세트 "+team1gamewin +":"+team2gamewin+ " team2 승리\n";

		String totalscore = "<총 경기 결과>\n"+p+"팀 승리\n";            //전체 score 정리할 문자열
		String line1,line2, line3, line4, line5, line6, line7, line8, line9; 

		line1 = "─".repeat(25);
		line2 = "Game	Team 1		Team 2\n";
		line3 = " 1		  "+ scoreArr[0][0]+"			  " + scoreArr[1][0]+"\n";  //*******
		line4 = " 2		  "+ scoreArr[0][1]+"			  " + scoreArr[1][1]+"\n";
		line5 = " 3		  "+ scoreArr[0][2]+"			  " + scoreArr[1][2]+"\n";
		line6 = " 4		  "+ scoreArr[0][3]+"			  " + scoreArr[1][3]+"\n";
		line7 = " 5		  "+ scoreArr[0][4]+"			  " + scoreArr[1][4]+"\n";
		line8 = "\n Tot	  "+ scores[0][2]+"			  " + scores[1][2]+"\n";

		String line = line2+line3+line4+line5+line6+line7;

		if (p == 1) totalscore += "승자 : " + Player.team1player+"\n\n"+line1+"\n"+line+line1+line8+line1;

		//+"\n"+team1line+"\n"+team2line;
		else totalscore += "승자 : " + Player.team2player+"\n\n"+line1+"\n"+line+line1+line8+line1;

		//+"\n"+team1line+"\n"+team2line;


		txtout(totalscore);


	} //totalscoreprint()
}// GameMethod (class)

